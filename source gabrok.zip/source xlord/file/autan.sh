#!/bin/bash
# Color Validation
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
blue='\e[34m'
PURPLE='\e[35m'
cyan='\e[36m'
Lred='\e[91m'
Lgreen='\e[92m'
g="\e[36m"
gb="\e[92;1m"
Lyellow='\e[93m'
NC='\e[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
LIGHT='\033[0;37m'
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
####
function line_atas(){
echo -e " ${CYAN}┌─────────────────────────────────────┐${p}"
}
function line_bawah() {
echo -e " ${CYAN}└─────────────────────────────────────┘${p}"
}
function line_tengah() {
echo -e " ${CYAN}────────────────────────────────────────${p}"
}
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
purple() { echo -e "\\033[35;1m${*}\\033[0m"; }
tyblue() { echo -e "\\033[36;1m${*}\\033[0m"; }
yellow() { echo -e "\\033[33;1m${*}\\033[0m"; }
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
clear
line_atas
purple "       •••• AUTO REBOOT PANEL •••• "
line_bawah
line_atas
echo -e " ${g}│  ${gb}[1]• ${b} Set Auto-Reboot Setiap 1 Jam"
echo -e " ${g}│  ${gb}[2]• ${b} Set Auto-Reboot Setiap 6 Jam"
echo -e " ${g}│  ${gb}[3]• ${b} Set Auto-Reboot Setiap 12 Jam"
echo -e " ${g}│  ${gb}[4]• ${b} Set Auto-Reboot Setiap 1 Hari"
echo -e " ${g}│  ${gb}[5]• ${b} Set Auto-Reboot Setiap 1 Minggu"
echo -e " ${g}│  ${gb}[6]• ${b} Set Auto-Reboot Setiap 1 Bulan"
echo -e " ${g}│  ${gb}[7]• ${b} Matikan Auto-Reboot"
echo -e " ${g}│  ${gb}[8]• ${b} View reboot log"
echo -e " ${g}│  ${gb}[9]• ${b} Remove reboot log"
line_bawah
line_atas
echo -e " ${g}│  ${gb}[0]• ${b} Go Back To Menu"
line_bawah
echo -e ""
read -p " Select menu : " x
if test $x -eq 1; then
echo "10 * * * * root /usr/local/bin/reboot_otomatis" > /etc/cron.d/reboot_otomatis
echo "Auto-Reboot has been set every an hour."
elif test $x -eq 2; then
echo "10 */6 * * * root /usr/local/bin/reboot_otomatis" > /etc/cron.d/reboot_otomatis
echo "Auto-Reboot has been successfully set every 6 hours."
elif test $x -eq 3; then
echo "10 */12 * * * root /usr/local/bin/reboot_otomatis" > /etc/cron.d/reboot_otomatis
echo "Auto-Reboot has been successfully set every 12 hours."
elif test $x -eq 4; then
echo "10 0 * * * root /usr/local/bin/reboot_otomatis" > /etc/cron.d/reboot_otomatis
echo "Auto-Reboot has been successfully set once a day."
elif test $x -eq 5; then
echo "10 0 */7 * * root /usr/local/bin/reboot_otomatis" > /etc/cron.d/reboot_otomatis
echo "Auto-Reboot has been successfully set once a week."
elif test $x -eq 6; then
echo "10 0 1 * * root /usr/local/bin/reboot_otomatis" > /etc/cron.d/reboot_otomatis
echo "Auto-Reboot has been successfully set once a month."
elif test $x -eq 7; then
rm -f /etc/cron.d/reboot_otomatis
echo "Auto-Reboot successfully TURNED OFF."
elif test $x -eq 8; then
if [ ! -e /root/log-reboot.txt ]; then
	clear
    line_atas
purple "       •••• AUTO REBOOT LOG •••• "
line_bawah
line_atas
    echo -e ""
    echo "No reboot activity found"
    echo -e ""
line_tengah
    echo ""
    read -n 1 -s -r -p "Press any key to back on menu"
    auto-reboot
	else
	clear
    line_atas
purple "       •••• AUTO REBOOT LOG •••• "
line_bawah
line_atas
    echo -e ""    
	echo 'LOG REBOOT'
	cat /root/log-reboot.txt
    echo -e ""
line_tengah
    echo ""
    read -n 1 -s -r -p "Press any key to back on menu"
    auto-reboot    
fi
elif test $x -eq 9; then
clear
line_atas
purple "       •••• AUTO REBOOT LOG •••• "
line_bawah
line_atas
echo -e ""  
echo "" > /root/log-reboot.txt
echo "Auto Reboot Log successfully deleted!"
echo -e ""
line_tengah
echo ""
read -n 1 -s -r -p "Press any key to back on menu"
auto-reboot 
elif test $x -eq 0; then
clear
menu
else
clear
echo ""
echo "Options Not Found In Menu"
echo ""
read -n 1 -s -r -p "Press any key to back on menu"
auto-reboot
fi
