#!/bin/bash
MYIP=$(wget -qO- ipinfo.io/ip);
echo "Loading...."
sleep 0.5
CEKEXPIRED () {
        today=$(date -d +1day +%Y -%m -%d)
        Exp1=$(curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | grep $MYIP | awk '{print $3}')
        if [[ $today < $Exp1 ]]; then
        echo "status script aktif.."
        else
        echo "SCRIPT ANDA EXPIRED";
        exit 0
fi
}
IZIN=$(curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | awk '{print $4}' | grep $MYIP)
if [ $MYIP = $IZIN ]; then
echo "Welcome To Sc Premium.."
sleep 1
else
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    echo -e "\033[42m          404 NOT FOUND AUTOSCRIPT          \033[0m"
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    echo -e ""
    echo -e "            ${RED}PERMISSION DENIED !${NC}"
    echo -e "   \033[0;33mYour VPS${NC} $MYIP \033[0;33mHas been Banned${NC}"
    echo -e "     \033[0;33mBuy access permissions for scripts${NC}"
    echo -e "             \033[0;33mContact Admin :${NC}"
    echo -e "      \033[0;36mTelegram${NC} t.me/xlordeuyy"
    echo -e "      ${GREEN}WhatsApp${NC} wa.me/62881036683241"
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    exit
exit 0
fi
clear
#EXPIRED
expired=$(curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | grep $MYIP | awk '{print $3}')
echo $expired > /root/expired.txt
today=$(date -d +1day +%Y-%m-%d)
while read expired
do
        exp=$(echo $expired | curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | grep $MYIP | awk '{print $3}')
        if [[ $exp < $today ]]; then
                Exp2="\033[1;31mExpired\033[0m"
        else
        Exp2=$(curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | grep $MYIP | awk '{print $3}')
        fi
done < /root/expired.txt
rm /root/expired.txt
clear
# Color Validation
purple() { echo -e "\\033[35;1m${*}\\033[0m"; }
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
b='\e[34m'
PURPLE='\e[35m'
gb='\033[0;37m'
cyan='\e[36m'
g='\e[36m'
Lred='\e[91m'
Lgreen='\e[92m'
Lyellow='\e[93m'
NC='\e[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
LIGHT='\033[0;37m'
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
######################################

# // ───>>> BACKGROUND

function line_atas(){
echo -e "  ${g}┌─────────────────────────────────────────────────┐${p}"
}
function line_bawah() {
echo -e "  ${g}└─────────────────────────────────────────────────┘${p}"
}
function line_p(){
echo -e "  ${g}┌─────────────────────────────────────────────────•${p}"
}
function line_l() {
echo -e "  ${g}└─────────────────────────────────────────────────•${p}"
}
function line_ip() {
echo -e "  ${g}•─────────────────────────────────────────────────•${p}"
}
function line_pp() {
echo -e "  ${g}┌─────────────────────────────────•${p}"
}
function line_oo() {
echo -e "  ${g}└─────────────────────────────────•${p}"
}
function line_ae(){
echo -e "  ${g}•─────────────────────────────────────────────────┐${p}"
}
function line_ai() {
echo -e "  ${g}•─────────────────────────────────────────────────┘${p}"
}
BG_GRN="\033[42;1m" # BG HIJAU
BG_RED="\033[45;1m" # BG MERAH
BG_CYN="\033[46;1m" # BG CYANN
BG_BLU="\033[44;1m" # BG BIRU
BG_PUR="\033[43;1m" # BG KUNING
BG_YEL="\033[93;1m" # BG konengWaduk
BG_WHT="\033[47;1m" # BG PUTIH
BG_RED="\033[41;97;1m" # BG MERAH
# VPS Information
#Domain
domain=$(cat /etc/xray/domain)
#Status certificate
modifyTime=$(stat $HOME/.acme.sh/${domain}_ecc/${domain}.key | sed -n '7,6p' | awk '{print $2" "$3" "$4" "$5}')
modifyTime1=$(date +%s -d "${modifyTime}")
currentTime=$(date +%s)
cpu_usage1="$(ps aux | awk 'BEGIN {sum=0} {sum+=$3}; END {print sum}')"
cpu_usage="$((${cpu_usage1/\.*} / ${coREDiilik:-1}))"
cpu_usage+=" %"
stampDiff=$(expr ${currentTime} - ${modifyTime1})
days=$(expr ${stampDiff} / 86400)
MODEL=$(cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/"//g' | sed 's/PRETTY_NAME//g')
remainingDays=$(expr 90 - ${days})
tlsStatus=${remainingDays}
if [[ ${remainingDays} -le 0 ]]; then
        tlsStatus="expired"
fi
DATE=$(date +'%Y-%m-%d')
datediff() {
    d1=$(date -d "$1" +%s)
    d2=$(date -d "$2" +%s)
    echo -e "$COLOR1 $NC Expiry In   : $(( (d1 - d2) / 86400 )) Days"
}
mai="datediff "$Exp" "$DATE""

today=`date -d "0 days" +"%Y-%m-%d"`

# CERTIFICATE STATUS
Name=$(curl https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | grep $MYIP | awk '{print $2}')
d1=$(date -d "$exp" +%s)
d2=$(date -d "$today" +%s)
certificate=$(( (d1 - d2) / 86400 ))
# OS Uptime
uptime="$(uptime -p | cut -d " " -f 2-10)"
# Download
vnstat_profile=$(vnstat | sed -n '3p' | awk '{print $1}' | grep -o '[^:]*')
vnstat -i ${vnstat_profile} >/root/t1
bulan=$(date +%b)
today=$(vnstat -i ${vnstat_profile} | grep today | awk '{print $8}')
todayd=$(vnstat -i ${vnstat_profile} | grep today | awk '{print $8}')
today_v=$(vnstat -i ${vnstat_profile} | grep today | awk '{print $9}')
today_rx=$(vnstat -i ${vnstat_profile} | grep today | awk '{print $2}')
today_rxv=$(vnstat -i ${vnstat_profile} | grep today | awk '{print $3}')
today_tx=$(vnstat -i ${vnstat_profile} | grep today | awk '{print $5}')
today_txv=$(vnstat -i ${vnstat_profile} | grep today | awk '{print $6}')
if [ "$(grep -wc ${bulan} /root/t1)" != '0' ]; then
    bulan=$(date +%b)
    month=$(vnstat -i ${vnstat_profile} | grep "$bulan " | awk '{print $9}')
    month_v=$(vnstat -i ${vnstat_profile} | grep "$bulan " | awk '{print $10}')
    month_rx=$(vnstat -i ${vnstat_profile} | grep "$bulan " | awk '{print $3}')
    month_rxv=$(vnstat -i ${vnstat_profile} | grep "$bulan " | awk '{print $4}')
    month_tx=$(vnstat -i ${vnstat_profile} | grep "$bulan " | awk '{print $6}')
    month_txv=$(vnstat -i ${vnstat_profile} | grep "$bulan " | awk '{print $7}')
else
    bulan=$(date +%Y-%m)
    month=$(vnstat -i ${vnstat_profile} | grep "$bulan " | awk '{print $8}')
    month_v=$(vnstat -i ${vnstat_profile} | grep "$bulan " | awk '{print $9}')
    month_rx=$(vnstat -i ${vnstat_profile} | grep "$bulan " | awk '{print $2}')
    month_rxv=$(vnstat -i ${vnstat_profile} | grep "$bulan " | awk '{print $3}')
    month_tx=$(vnstat -i ${vnstat_profile} | grep "$bulan " | awk '{print $5}')
    month_txv=$(vnstat -i ${vnstat_profile} | grep "$bulan " | awk '{print $6}')
fi
# Getting CPU Information
cpu_usage1="$(ps aux | awk 'BEGIN {sum=0} {sum+=$3}; END {print sum}')"
cpu_usage="$((${cpu_usage1/\.*} / ${corediilik:-1}))"
cpu_usage+=" %"
ISP=$(cat /usr/local/etc/xray/org)
WKT=$(cat /usr/local/etc/xray/timezone)
DAY=$(date +%A)
DATE=$(date +%m/%d/%Y)
DATE2=$(date -R | cut -d " " -f -5)
IPVPS=$(curl -s ipinfo.io/ip )
cname=$( awk -F: '/model name/ {name=$2} END {print name}' /proc/cpuinfo )
cores=$( awk -F: '/model name/ {core++} END {print core}' /proc/cpuinfo )
freq=$( awk -F: ' /cpu MHz/ {freq=$2} END {print freq}' /proc/cpuinfo )
tram=$( free -m | awk 'NR==2 {print $2}' )
uram=$( free -m | awk 'NR==2 {print $3}' )
fram=$( free -m | awk 'NR==2 {print $4}' )

#STATUS RUNNING
cek=$(service ssh status | grep active | cut -d ' ' -f5)

if [ "$cek" = "active" ]; then

stat=-f5

else

stat=-f7

fi
ssh=$(service ssh status | grep active | cut -d ' ' $stat)
if [ "$ssh" = "active" ]; then
xssh="${green}[RUN]${NC}"
else
xssh="${red}[OFF]${NC}"
fi
nginx=$(service nginx status | grep active | cut -d ' ' $stat)
if [ "$nginx" = "active" ]; then
xnginx="${green}[RUN]${NC}"
else
xnginx="${red}[OFF]${NC}"
fi
xray=$(service xray status | grep active | cut -d ' ' $stat)
if [ "$xray" = "active" ]; then
xxray="${green}[RUN]${NC}"
else
xxray="${red}[OFF]${NC}"
fi
clear 
line_atas
echo -e " ${CYAN} │ ${gb}${BG_CYN}               ∆  XLORD × DIMZ  ∆              ${NC} ${CYAN}│$NC"
line_bawah
line_p
echo -e " ${CYAN} │$NC $gb ISP ${gb}              : ${gb}$ISP${NC}"
echo -e " ${CYAN} │$NC $gb System Os ${gb}        : ${gb}$MODEL${NC}"
echo -e " ${CYAN} │$NC $gb IP VPS ${gb}           : ${gb}$IPVPS${NC}"
echo -e " ${CYAN} │$NC $gb DOMAIN ${gb}           : $gb$domain"
echo -e " ${CYAN} │$NC $gb UPTIME ${gb}           : $gb$uptime"
echo -e " ${CYAN} │$NC $gb RAM USAGE ${gb}        : $gb$uram MB | $gb$tram MB"
echo -e " ${CYAN} │$NC $gb CPU USAGE ${gb}        : $gb$cpu_usage"
line_l
line_ae
echo -e " $NC   ${gb}HARIAN ${p}: ${b}$todayd $today_v  ${g} │  ${gb}BULANAN ${p}: ${b}$month  $month_v"
line_ai
line_atas
echo -e "  ${g}│  ${gb} SSH WS : $xssh ${gb} NGINX : $xnginx ${gb} XRAY : $xxray   ${g}│$NC"
line_bawah
line_p
echo -e "  ${g}│$NC    ${gb}[01] • $NC${g} SSH MENU     $NC ${gb}[05] • ${g} TCP BBR"
echo -e "  ${g}│$NC    ${gb}[02] • $NC${g} VMESS MENU   $NC ${gb}[06] • ${g} UBAH BANNER"
echo -e "  ${g}│$NC    ${gb}[03] • $NC${g} VLESS MENU   $NC ${gb}[07] • ${g} RUNNING"
echo -e "  ${g}│$NC    ${gb}[04] • $NC${g} TROJAN MENU  $NC ${gb}[08] • ${g} RESTART MENU"
line_l
line_ae
echo -e "  $NC    ${gb}[09] • $NC${g} SPEEDTEST    $NC ${gb}[10] • ${g} DOMAIN MENU     ${g}│$NC"
echo -e "  $NC    ${gb}[11] • $NC${g} BACKUP MENU  $NC ${gb}[12] • ${g} DNS MANAGER     ${g}│$NC"
echo -e "  $NC    ${gb}[44] • ${g} XRAY USAGE  $NC  ${gb}[66] • ${g} MENU RESELLER   ${g}│$NC"
echo -e "  $NC    ${gb}[55] • ${g} BOT MANAGEMENT                        ${g}│$NC"
line_ai
line_atas
echo -e "  ${g}│$NC ${gb}[22] • $NC${red} REBOOT VPS   $NC ${gb}[33] • ${red} SERVER MONITORING ${g}│$NC"
line_bawah
line_pp
echo -e "  ${g}│$gb VERSION      : 1.0"
echo -e "  ${g}│$gb NAME CLIENT  : $Name"
echo -e "  ${g}│$gb EXP SCRIPT   : $Exp2 | $certificate Day"
echo -e "  ${g}│$gb OWNER        : 𝙓𝙡𝙤𝙧𝙙𝘿𝙞𝙢𝙯𝙓𝘿"
line_oo
line_ip
echo ""
read -p "   Select menu (01-66) => "  opt
echo -e   ""
case $opt in
1) clear ; m-sshovpn ;;
2) clear ; m-vmess ;;
3) clear ; m-vless ;;
4) clear ; m-trojan ;;
5) clear ; menu-tcp ;;
6) clear ; nano /etc/issue.net ;;
7) clear ; running ;;
8) clear ; restart ;;
9) clear ; speedtest ;;
10) clear ; m-domain;;
11) clear ; backupmenu ;;
12) clear ; dns ;;
22) clear ; reboot ;;
33) clear ; gotop ;;
44) clear ; xraymonitor ;;
55) clear ; botmenu ;;
66) clear ; daftar ;;
x) exit ;;
*) menu ;;
esac