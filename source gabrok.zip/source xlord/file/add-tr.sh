#!/bin/bash
# Provide by xlrd × dimz
# Color Validation
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
blue='\e[34m'
PURPLE='\e[35m'
g="\033[1;93m"
gb="\e[92;1m"
cyan='\e[36m'
Lred='\e[91m'
Lgreen='\e[92m'
Lyellow='\e[93m'
NC='\e[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
LIGHT='\033[0;37m'
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
purple() { echo -e "\\033[35;1m${*}\\033[0m"; }
tyblue() { echo -e "\\033[36;1m${*}\\033[0m"; }
yellow() { echo -e "\\033[33;1m${*}\\033[0m"; }
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
clear
function line_atas(){
echo -e " ${CYAN}┌─────────────────────────────────┐${p}"
}
function line_bawah() {
echo -e " ${CYAN}└─────────────────────────────────┘${p}"
}
function line_tengah() {
echo -e "   ${CYAN}────────────────────────────────────────${p}"
}
clear
source /var/lib/xlordhost/ipvps.conf
domain=$(cat /etc/xray/domain)
ISP=$(cat /usr/local/etc/xray/org)
CITY=$(cat /usr/local/etc/xray/city)
line_atas
purple "   •••• CREATE TROJAN ACCOUNT •••• "
line_bawah
read -rp "User: " -e user
if [ -z ${user} ]; then
add-tr
fi
user_EXISTS=$(grep -w $user /etc/xray/config.json | wc -l)
if [[ ${user_EXISTS} == '4' ]]; then
red "User Already Exist"
sleep 2
menu
else
read -p "Quota (GB) : " Quota
read -p "Expired (days): " masaaktif
if [ -z ${Quota} ]; then
  Quota="1"
fi
c=$(echo "${Quota}" | sed 's/[^0-9]*//g')
d=$((${c} * 1024 * 1024 * 1024))
if [[ ${c} != "0" ]]; then
  echo "${d}" >/etc/lmt/${user}
fi
usg="1024"
echo "$usg" >/etc/usg/${user}

uuid=$(cat /proc/sys/kernel/random/uuid)
tgl=$(date -d "$masaaktif days" +"%d")
bln=$(date -d "$masaaktif days" +"%b")
thn=$(date -d "$masaaktif days" +"%Y")
expe="$tgl $bln, $thn"
tgl2=$(date +"%d")
bln2=$(date +"%b")
thn2=$(date +"%Y")
tnggl="$tgl2 $bln2, $thn2"
exp=`date -d "$masaaktif days" +"%Y-%m-%d"`
sed -i '/#trojanws$/a\#! '"$user $exp"'\
},{"password": "'""$uuid""'","email": "'""$user""'"' /etc/xray/config.json
sed -i '/#trojangrpc$/a\#! '"$user $exp"'\
},{"password": "'""$uuid""'","email": "'""$user""'"' /etc/xray/config.json

trojanlink1="trojan://${uuid}@${domain}:443?mode=gun&security=tls&type=grpc&serviceName=trojan-grpc&sni=bug.com#${user}"
trojanlink="trojan://${uuid}@bugkamu.com:443?path=%2Ftrojan-ws&security=tls&host=${domain}&type=ws&sni=${domain}#${user}"
trojanlink2="trojan://${uuid}@${domain}:80?path=%2Ftrojan-ws&security=none&host=${domain}&type=ws#${user}"

systemctl restart xray
sed -i '$ a\#! '"$user $exp"'' /etc/client/trj.txt
clear
echo -e "${BLUE}--------------------------------------\033[0m" | tee -a /etc/xraylog/log-trojan-$user.txt
    echo -e " ∆ TROJAN ACCOUNT ∆  " | tee -a /etc/xraylog/log-trojan-$user.txt
echo -e "${BLUE}--------------------------------------\033[0m" | tee -a /etc/xraylog/log-trojan-$user.txt
echo -e "Remarks        : ${user}" | tee -a /etc/xraylog/log-trojan-$user.txt
echo -e "Quota          : ${Quota} GB" | tee -a /etc/xraylog/log-trojan-$user.txt
echo -e "Host/IP        : ${domain}" | tee -a /etc/xraylog/log-trojan-$user.txt
echo -e "ISP            : ${ISP}" | tee -a /etc/xraylog/log-trojan-$user.txt
echo -e "Region         : ${CITY}" | tee -a /etc/xraylog/log-trojan-$user.txt
echo -e "Port TLS/gRPC  : 443, 8443, 2053, 2083, 2087, 2096" | tee -a /etc/xraylog/log-trojan-$user.txt
echo -e "Port none TLS  : 80, 2082, 8880, 8080, 2095, 2086, 2052" | tee -a /etc/xraylog/log-trojan-$user.txt
echo -e "Key            : ${uuid}" | tee -a /etc/xraylog/log-trojan-$user.txt
echo -e "Path           : /trojan" | tee -a /etc/xraylog/log-trojan-$user.txt
echo -e "Service Name   : trojan-grpc" | tee -a /etc/xraylog/log-trojan-$user.txt
echo -e "${BLUE}--------------------------------------\033[0m" | tee -a /etc/xraylog/log-trojan-$user.txt
echo -e "Link TLS       : ${trojanlink}" | tee -a /etc/xraylog/log-trojan-$user.txt
echo -e "${RED}--------------------------------------\033[0m" | tee -a /etc/xraylog/log-trojan-$user.txt
echo -e "Link none TLS  : ${trojanlink2}" | tee -a /etc/xraylog/log-trojan-$user.txt
echo -e "${BLUE}--------------------------------------\033[0m" | tee -a /etc/xraylog/log-trojan-$user.txt
echo -e "Link gRPC      : ${trojanlink1}" | tee -a /etc/xraylog/log-trojan-$user.txt
echo -e "${RED}--------------------------------------\033[0m" | tee -a /etc/xraylog/log-trojan-$user.txt
echo -e "Expired On     : $exp" | tee -a /etc/xraylog/log-trojan-$user.txt
echo -e "${BLUE}--------------------------------------\033[0m" | tee -a /etc/xraylog/log-trojan-$user.txt
echo "" | tee -a /etc/xraylog/log-trojan-$user.txt

ISP=$(curl -s ipinfo.io/org | cut -d " " -f 2-10)
CITY=$(wget -qO- ipinfo.io/city)
TIME=$(date +'%Y-%m-%d %H:%M:%S')
TIMES="10"
CHATID="-1002100547917"
KEY="6761427805:AAFuwglpszmsioSVrj6MHhYGMBqX2IHqXdE"
URL="https://api.telegram.org/bot$KEY/sendMessage"
TEXT="
<code>•──────────────────•</code>
<b>  👾 New Transaction 👾      </b>
<code>•──────────────────•</code>
<code>ISP      : $ISP</code>
<code>CITY     : $CITY</code>
<code>DOMAIN   : $domain</code>
<code>DATE     : $TIME</code>
<code>DETAIL   : Trojan Account</code>
<code>DURASI   : $masaaktif Day</code>
<code>•──────────────────•</code>
<i>✨ Thank you $user for order ✨</i>
"
curl -s --max-time $TIMES -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" $URL >/dev/null

read -n 1 -s -r -p "Press any key to back"
m-trojan
fi
