#!/bin/bash
# Provide by xlrd × dimz
# Color Validation
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
blue='\e[34m'
PURPLE='\e[35m'
g="\033[1;93m"
gb="\e[92;1m"
cyan='\e[36m'
Lred='\e[91m'
Lgreen='\e[92m'
Lyellow='\e[93m'
NC='\e[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
LIGHT='\033[0;37m'
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
purple() { echo -e "\\033[35;1m${*}\\033[0m"; }
tyblue() { echo -e "\\033[36;1m${*}\\033[0m"; }
yellow() { echo -e "\\033[33;1m${*}\\033[0m"; }
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
clear
function line_atas(){
echo -e " ${CYAN}┌─────────────────────────────────┐${p}"
}
function line_bawah() {
echo -e " ${CYAN}└─────────────────────────────────┘${p}"
}
function line_tengah() {
echo -e "${CYAN}┌──────────────────────────────┐${p}"
}
function line_kecil() {
echo -e "${CYAN}└──────────────────────────────┘${p}"
}
clear
line_atas
purple "     •••• VMESS MONITORING •••• "
line_bawah
echo ""
function totalusage() {
    local -i bytes=$1;
    if [[ $bytes -lt 1024 ]]; then
        echo "${bytes}B"
    elif [[ $bytes -lt 1048576 ]]; then
        echo "$(( (bytes + 1023)/1024 ))KB"
    elif [[ $bytes -lt 1073741824 ]]; then
        echo "$(( (bytes + 1048575)/1048576 ))MB"
    else
        echo "$(( (bytes + 1073741823)/1073741824 ))GB"
    fi
}

data=( `cat /etc/client/vms.txt | grep '###' | cut -d ' ' -f 2 | sort | uniq`);
for akun in "${data[@]}"
do
if [[ -z "$akun" ]]; then
echo -e "Vmess user not found"
echo ""
fi
for user in "${akun[@]}"; do
        user_file="/etc/usg/${user}"
        if [ -f "$user_file" ]; then
            USAGE=$(cat "$user_file")
            tousg=$(totalusage $USAGE)
            limit_file="/etc/lmt/${user}"
            if [ -f "$limit_file" ]; then
                LIMIT=$(cat "$limit_file")
                tolmt=$(totalusage $LIMIT)
            fi
        fi
done
for status in "${akun[@]}"; do
         sts_usr=$(cat /var/log/xray/access.log | grep $akun | wc -l)
         if [[ ${sts_usr} == '0' ]]; then
         userstatus="${RED}Offline${NC}"
         else
         userstatus="${BLUE}Online${NC}"
         fi
done
if [[ -z "$akun" ]]; then
red " There are no members"
else
line_tengah
echo -e "   Username    : ${GREEN}$akun${NC}";
echo -e "   Quota Usage : ${ORANGE}$tousg${NC}/${RED}$tolmt${NC}";
echo -e "   User Status : $userstatus";
line_kecil
fi
done
read -n 1 -s -r -p "Press any key to back"
clear
xraymonitor
