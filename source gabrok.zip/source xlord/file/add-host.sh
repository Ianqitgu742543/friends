#!/bin/bash
# Provide by xlrd × dimz
# Color Validation
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
blue='\e[34m'
PURPLE='\e[35m'
cyan='\e[36m'
Lred='\e[91m'
Lgreen='\e[92m'
Lyellow='\e[93m'
NC='\e[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
LIGHT='\033[0;37m'
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
purple() { echo -e "\\033[35;1m${*}\\033[0m"; }
tyblue() { echo -e "\\033[36;1m${*}\\033[0m"; }
yellow() { echo -e "\\033[33;1m${*}\\033[0m"; }
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
clear
domain=$(cat /etc/xray/domain)
IP=$(cat /etc/securedata/ip1)
ISP=$(cat /usr/local/etc/xray/org)
function line_atas(){
echo -e " ${CYAN}┌─────────────────────────────────────┐${p}"
}
function line_bawah() {
echo -e " ${CYAN}└─────────────────────────────────────┘${p}"
}
function line_tengah() {
echo -e "   ${CYAN}────────────────────────────────────────${p}"
}
clear
clear
line_atas
purple "       •••• Ganti Domain ••••            \E[0m"
line_bawah
echo ""
echo " Your Current Domain : $domain"
echo " IP                  : $IP"
echo " ISP                 : $ISP"
echo ""
read -rp "New Domain: " -e host
echo ""
if [ -z $host ]; then
menu
else
echo "IP=$host" > /var/lib/xlordhost/ipvps.conf
echo "$host" > /etc/xray/domain
red "Domain Added"
echo "Please Renew Your SSl Certificate after this !!!"
echo ""
read -n 1 -s -r -p "Press any key to back"
m-domain
fi
