#!/bin/bash
# Valid Script
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
blue='\e[34m'
PURPLE='\e[35m'
g="\e[36m"
gb='\033[0;37m'
cyan='\e[36m'
Lred='\e[91m'
Lgreen='\e[92m'
Lyellow='\e[93m'
NC='\e[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
LIGHT='\033[0;37m'
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
purple() { echo -e "\\033[35;1m${*}\\033[0m"; }
tyblue() { echo -e "\\033[36;1m${*}\\033[0m"; }
yellow() { echo -e "\\033[33;1m${*}\\033[0m"; }
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
clear
function line_atas(){
echo -e " ${CYAN}┌─────────────────────────────────────┐${p}"
}
function line_bawah() {
echo -e " ${CYAN}└─────────────────────────────────────┘${p}"
}
function line_tengah() {
echo -e "   ${CYAN}────────────────────────────────────────${p}"
}
clear
MYIP=$(wget -qO- ipinfo.io/ip);


mkdir -p /etc/ssnvpn
mkdir -p /etc/ssnvpn/theme
mkdir -p /var/lib/ssnvpn-pro >/dev/null 2>&1

APIGIT="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"
EMAILGIT="salamsatuuuu@gmail.com"
USERGIT="salamsatuu"

ipsaya=$(wget -qO- ipinfo.io/ip)
data_server=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
date_list=$(date +"%Y-%m-%d" -d "$data_server")
data_ip="https://raw.githubusercontent.com/salamsatuu/psby/main/daftar"
checking_sc() {
  useexp=$(wget -qO- $data_ip | grep $ipsaya | awk '{print $3}')
  if [[ $date_list < $useexp ]]; then
    echo -ne
  else
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    echo -e "\033[42m          404 NOT FOUND AUTOSCRIPT          \033[0m"
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    echo -e ""
    echo -e "            ${RED}PERMISSION DENIED !${NC}"
    echo -e "   \033[0;33mYour VPS${NC} $ipsaya \033[0;33mHas been Banned${NC}"
    echo -e "     \033[0;33mBuy access permissions for scripts${NC}"
    echo -e "             \033[0;33mContact Admin :${NC}"
    echo -e "      \033[0;36mTelegram${NC} t.me/xlordeeuyy"
    echo -e "      ${GREEN}WhatsApp${NC} wa.me/0881036683241"
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    exit
  fi
}
checking_sc


function setapi(){
    clear
line_atas
purple "       •••• SET API TOKE ••••            \E[0m"
line_bawah
line_atas
if [[ -f /etc/ssnvpn/github/api && -f /etc/ssnvpn/github/email && /etc/ssnvpn/github/username ]]; then
   rec="OK"
else
    mkdir /etc/ssnvpn/github > /dev/null 2>&1
fi

read -p " E-mail   : " EMAIL1
if [ -z $EMAIL1 ]; then
echo -e "$COLOR1${NC}   [INFO] Please Input Your Github Email Adress"
line_bawah  
echo -e ""
read -n 1 -s -r -p "   Press any key to back on menu"
daftar
fi

read -p " Username : " USERNAME1
if [ -z $USERNAME1 ]; then
echo -e "$COLOR1${NC}   [INFO] Please Input Your Github Username"
line_bawah
echo -e ""
read -n 1 -s -r -p "   Press any key to back on menu"
daftar
fi

read -p " API      : " API1
if [ -z $API1 ]; then
echo -e "$COLOR1${NC}  [INFO] Please Input Your Github API"
line_bawah
echo -e ""
read -n 1 -s -r -p "  Press any key to back on menu"
daftar
fi

sleep 2
echo "$EMAIL1" > /etc/ssnvpn/github/email
echo "$USERNAME1" > /etc/ssnvpn/github/username
echo "$API1" > /etc/ssnvpn/github/api
echo "ON" > /etc/ssnvpn/github/gitstat
clear
line_atas
purple "       •••• SET API TOKEN ••••            \E[0m"
line_bawah
line_atas
echo -e "$COLOR1${NC}   [INFO] Github Api Setup Successfully"
echo -e "$COLOR1${NC}"
echo -e "$COLOR1${NC}   • Email : $EMAIL1"
echo -e "$COLOR1${NC}   • User  : $USERNAME1"
echo -e "$COLOR1${NC}   • API   : $API1"
line_bawah
echo -e ""
read -n 1 -s -r -p "   Press any key to back on menu"
daftar
}

function viewapi(){
    clear
line_atas
purple "       •••• DATA API RESELLER ••••            \E[0m"
line_bawah
line_atas
echo -e "$COLOR1${NC}  • Email : $EMAILGIT"
echo -e "$COLOR1${NC}  • User  : $USERGIT"
echo -e "$COLOR1${NC}  • API   : $APIGIT"
echo -e "$COLOR1${NC}  • All U need Is Create a new repository "
echo -e "$COLOR1${NC}    & Nammed : permission "
line_bawah
echo -e ""
read -n 1 -s -r -p "   Press any key to back on menu"
daftar
}
Isadmin=$(curl -sS https://raw.githubusercontent.com/salamsatuu/psby/main/daftar | grep $MYIP | awk '{print $5}')
if [ "$Isadmin" = "OFF" ]; then
clear
line_atas
echo -e "\e[1;31m          PERMISSION DENIED!!"
echo -e "\e[34m  Join Reseller Dm Tele : t.me/xlordeuyy"
echo -e "\e[34m  SCRIPT BY : XLORD VPN ®${NC}"
line_bawah
echo -e ""
read -n 1 -s -r -p "   Press any key to back on menu"
menu  
fi
clear
line_atas
purple "       •••• MENU RESELLER ••••            \E[0m"
line_bawah
line_atas
GITREQ=/etc/ssnvpn/github/gitstat
if [ -f "$GITREQ" ]; then
    cekk="ok"
else 
    mkdir /etc/ssnvpn/github
    touch /etc/ssnvpn/github/gitstat
    echo "OFF" > /etc/ssnvpn/github/gitstat
fi

stst1=$(cat /etc/ssnvpn/github/gitstat)
if [ "$stst1" = "OFF" ]; then
clear
line_atas
purple "       •••• INPUT YOUR TOKEN ••••            \E[0m"
line_bawah
line_atas
purple "       •••• SILAKAN HUBUNGI OWNER ••••            \E[0m"
line_bawah
read -n 1 -s -r -p "   Press any key to Set API"
setapi
fi
stst=$(cat /etc/ssnvpn/github/gitstat)
if [ "$stst" = "ON" ]; then
#APIOK="CEK API"
rex="viewapi"
else
APIOK="SET API"
rex="setapi"
fi
if [ "$stst" = "ON" ]; then
ISON="RESET API"
ressee="resetipvps"
else
ISON=""
ressee="menu"
fi
echo -e " ${g}│  ${NC}${g} 1.$NC ${c}ADD IP RESSELER"$NC
echo -e " ${g}│  ${NC}${g} 2.$NC ${c}DELETE IP RESSELER"$NC
echo -e " ${g}│  ${NC}${g} 3.$NC ${c}RENEW IP RESSELER"$NC
echo -e " ${g}│  ${NC}${g} 4.$NC ${c}LIST USER IPVPS"$NC
line_bawah
line_atas
echo -e " ${g}│  ${gb}[0]• ${b} Go Back To Menu"
line_bawah
echo -e ""
read -p " Select menu :  "  opt
echo -e   ""
case $opt in
01 | 1) clear ; add-ip ;;
02 | 2) clear ; del-ip ;;
03 | 3) clear ; ren-ip ;;
04 | 4) clear ; show-ip ;;
00 | 0) clear ; menu ;;
*) clear ; menu ;;
esac 