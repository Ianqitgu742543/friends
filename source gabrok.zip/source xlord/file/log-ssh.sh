#!/bin/bash
# Color Validation
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
blue='\e[34m'
PURPLE='\e[35m'
cyan='\e[36m'
Lred='\e[91m'
Lgreen='\e[92m'
g="\033[1;93m"
gb="\e[92;1m"
Lyellow='\e[93m'
NC='\e[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
LIGHT='\033[0;37m'
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
####
function line_atas(){
echo -e " ${CYAN}┌─────────────────────────────────────┐${p}"
}
function line_bawah() {
echo -e " ${CYAN}└─────────────────────────────────────┘${p}"
}
function line_tengah() {
echo -e "   ${CYAN}────────────────────────────────────────${p}"
}
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
purple() { echo -e "\\033[35;1m${*}\\033[0m"; }
tyblue() { echo -e "\\033[36;1m${*}\\033[0m"; }
yellow() { echo -e "\\033[33;1m${*}\\033[0m"; }
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
clear
line_atas
purple "       •••• HISTORY AKUN SSH••••            \E[0m"
line_bawah
line_atas
purple "   USERNAME           EXPERIED             \E[0m"
line_bawah
line_atas 
while read expired
do
AKUN="$(echo $expired | cut -d: -f1)"
ID="$(echo $expired | grep -v nobody | cut -d: -f3)"
exp="$(chage -l $AKUN | grep "Account expires" | awk -F": " '{print $2}')"
status="$(passwd -S $AKUN | awk '{print $2}' )"
if [[ $ID -ge 1000 ]]; then
if [[ "$status" = "L" ]]; then
printf "%-17s %2s %-17s %2s \n" "    $AKUN"    "$exp     "
else
printf "%-17s %2s %-17s %2s \n" "    $AKUN"    "$exp     "
fi
fi
done < /etc/passwd
line_bawah
echo ""
read -rp "Input Username : " user                                                  
CLIENT_EXISTS=$(grep -w $user /etc/xraylog/log-ssh-$user.txt | wc -l)    
if [[ ${CLIENT_EXISTS} == '0' ]]; then              
clear                                                                        
echo "Failure User Not Found"                                                   
else                                                                        
clear                                                                        
echo -e "`cat "/etc/xraylog/log-ssh-$user.txt"`"
fi
read -n 1 -s -r -p "Press any key to back on menu"
m-sshovpn                                               
