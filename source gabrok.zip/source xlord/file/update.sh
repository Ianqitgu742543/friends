#!/bin/bash
## > Color Validation
g="\033[1;93m"
gb="\e[92;1m"
b="\033[0;36m"
p="\033[0m"
r="\033[0;31m"
y="\033[0;33"
MYIP=$(wget -qO- ipinfo.io/ip);
echo "Loading..."
clear
link="https://xlord.serv00.net"
function line_atas() {
echo -e " ${g}┌──────────────────────────────────────────┐${p}"
}
function line_bawah() {
echo -e " ${g}└──────────────────────────────────────────┘${p}"
}

function fun_bar() {
    CMD[0]="$1"
    CMD[1]="$2"
    (
        [[ -e $HOME/fim ]] && rm $HOME/fim
        ${CMD[0]} -y >/dev/null 2>&1
        ${CMD[1]} -y >/dev/null 2>&1
        touch $HOME/fim
    ) >/dev/null 2>&1 &
    tput civis
    echo -ne "  ${b}Please Wait Loading ${p}- ${g}["
    while true; do
        for ((i = 0; i < 18; i++)); do
            echo -ne "\033[0;32m▰"
            sleep 0.1s
        done
        [[ -e $HOME/fim ]] && rm $HOME/fim && break
        echo -e " ${g}]"
        sleep 1s
        tput cuu1
        tput dl1
        echo -ne "  ${b}Please Wait Loading ${p}- ${g}["
    done
    echo -e " ${g}]${p} -${y} OK !${p}"
    tput cnorm
}
function update(){ 
# download script
clear
cd /usr/bin
wget -q -O autokill "${link}///file/autokill.sh" && chmod +x autokill
wget -q -O backupgh "${link}///file/backupgh.sh" && chmod +x backupgh
wget -q -O backupmg "${link}///file/backupmg.sh" && chmod +x backupmg
wget -q -O backupmenu "${link}///file/backupmenu.sh" && chmod +x backupmenu
wget -q -O ceklim "${link}///file/ceklim.sh" && chmod +x ceklim
wget -q -O usernew "${link}///file/usernew.sh" && chmod +x usernew
wget -q -O add-tr "${link}///file/add-tr.sh" && chmod +x add-tr
wget -q -O add-vless "${link}///file/add-vless.sh" && chmod +x add-vless
wget -q -O add-ws "${link}///file/add-ws.sh" && chmod +x add-ws
wget -q -O buak "${link}///file/del-ssh.sh" && chmod +x buak
wget -q -O del-tr "${link}///file/del-tr.sh" && chmod +x del-tr
wget -q -O del-vless "${link}///file/del-vless.sh" && chmod +x del-vless
wget -q -O del-ws "${link}///file/del-ws.sh" && chmod +x del-ws
wget -q -O dns "${link}///file/dns.sh" && chmod +x dns
wget -q -O add-host "${link}///file/add-host.sh" && chmod +x add-host
wget -q -O m-domain "${link}///file/m-domain.sh" && chmod +x m-domain
wget -q -O log-ssh "${link}///file/log-ssh.sh" && chmod +x log-ssh
wget -q -O log-trojan "${link}//file/log-trojan.sh" && chmod +x log-trojan
wget -q -O log-vless "${link}//file/log-vless.sh" && chmod +x log-vless
wget -q -O log-vmess "${link}//file/log-vmess.sh" && chmod +x log-vmess
wget -q -O cek "${link}//file/cek.sh" && chmod +x cek
wget -q -O cek-tr "${link}//file/cek-tr.sh" && chmod +x cek-tr
wget -q -O cek-vless "${link}//file/cek-vless.sh" && chmod +x cek-vless
wget -q -O cek-ws "${link}//file/cek-ws.sh" && chmod +x cek-ws
wget -q -O member "${link}//file/member.sh" && chmod +x member
wget -q -O menu-tcp "${link}//file/menu-tcp.sh" && chmod +x menu-tcp
wget -q -O menu "${link}//file/menu.sh" && chmod +x menu
wget -q -O renew "${link}//file/renew.sh" && chmod +x renew
wget -q -O renew-tr "${link}//file/renew-tr.sh" && chmod +x renew-tr
wget -q -O renew-vless "${link}//file/renew-vless.sh" && chmod +x renew-vless
wget -q -O renew-ws "${link}//file/renew-ws.sh" && chmod +x renew-ws
wget -q -O restart "${link}//file/restart.sh" && chmod +x restart
wget -q -O running "${link}//file/running.sh" && chmod +x running
wget -q -O restoregh "${link}//file/restoregh.sh" && chmod +x restoregh
wget -q -O restoremg "${link}//file/restoremg.sh" && chmod +x restoremg

wget -q -O m-sshovpn "${link}//file/m-sshovpn.sh" && chmod +x m-sshovpn
wget -q -O certv2ray "${link}//file/certv2ray.sh" && chmod +x certv2ray
wget -q -O tendang "${link}//file/tendang.sh" && chmod +x tendang
wget -q -O m-trojan "${link}//file/m-trojan.sh" && chmod +x m-trojan
wget -q -O m-vless "${link}//file/m-vless.sh" && chmod +x m-vless
wget -q -O m-vmess "${link}//file/m-vmess.sh" && chmod +x m-vmess
wget -q -O xp "${link}//file/xp.sh" && chmod +x xp
wget -q -O booster "${link}//file/logcleaner.sh" && chmod +x booster
wget -q -O unlock "${link}//file/unlock.sh" && chmod +x unlock
wget -q -O lock "${link}//file/lock.sh" && chmod +x lock
wget -q -O xraymonitor "${link}//file/XrayMTR.sh" && chmod +x xraymonitor
wget -q -O usgvmess "${link}//file/VmessMTR.sh" && chmod +x usgvmess
wget -q -O usgvless "${link}//file/VlessMTR.sh" && chmod +x usgvless
wget -q -O usgtrojan "${link}//file/TrojanMTR.sh" && chmod +x usgtrojan
wget -q -O bwusage "${link}//file/vnstatdata.sh" && chmod +x bwusage
wget -q -O botmenu "${link}//file/botmenu.sh" && chmod +x botmenu
wget -q -O limitlog "${link}//file/limitlog.sh" && chmod +x limitlog
wget -q -O update "${link}//file/update.sh" && chmod +x update
wget -q -O neo "${link}//file/neo.sh" && chmod +x neo
wget -q -O wilcard "${link}//file/cf.sh" && chmod +x wilcard
wget -q -O daftar "${link}///file/ress.sh" && chmod +x daftar
wget -q -O add-ip "${link}///file/add-res.sh" && chmod +x add-ip
wget -q -O del-ip "${link}///file/del-res.sh" && chmod +x del-ip
wget -q -O ren-ip "${link}///file/ren-res.sh" && chmod +x ren-ip
wget -q -O show-ip "${link}///file/list-res.sh" && chmod +x show-ip

}
####
line_atas
   echo -e "  ${gb} Update System Script${p}"
   fun_bar 'update'
   line_bawah
   echo -e "   ${g}[INFO] ${b}Update Successfully... ${p}"
   sleep 1
   read -n 1 -s -r -p "Tekan Enter To Back Menu"
menu