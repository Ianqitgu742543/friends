#!/bin/bash
clear
NC='\e[0m'
ipsaya=$(wget -qO- ipinfo.io/ip)
data_server=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
date_list=$(date +"%Y-%m-%d" -d "$data_server")
data_ip="https://raw.githubusercontent.com/Ianqitgu742543/friends/blob/main/ip"
checking_sc() {
useexp=$(wget -qO- $data_ip | grep $ipsaya | awk '{print $3}')
if [[ $date_list < $useexp ]]; then
echo -ne
else
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo -e "\033[0;36m          DAFTAR KE OWNER DULU SU !!       \033[0m"
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
echo -e ""
echo -e "            ${RED}PERMISSION DENIED !${NC}"
echo -e "   \033[0;33mYour VPS${NC} $ipsaya \033[0;33mHas been Banned${NC}"
echo -e "     \033[0;33mBuy access permissions for scripts${NC}"
echo -e "              \033[0;33mContact Admin :${NC}"
echo -e "         \033[0;36mTelegram${NC} t.me/xlordeuyy"
echo -e "       ${GREEN}WhatsApp${NC} wa.me/62881036683241"
echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
exit
fi
}
checking_sc
# Color Validation
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
blue='\e[34m'
PURPLE='\e[35m'
cyan='\e[36m'
Lred='\e[91m'
Lgreen='\e[92m'
Lyellow='\e[93m'
NC='\e[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
LIGHT='\033[0;37m'
# Color
RED='\033[0;31m'
NC='\033[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
LIGHT='\033[0;37m'
purple() { echo -e "\\033[35;1m${*}\\033[0m"; }
tyblue() { echo -e "\\033[36;1m${*}\\033[0m"; }
yellow() { echo -e "\\033[33;1m${*}\\033[0m"; }
green() { echo -e "\\033[32;1m${*}\\033[0m"; }
red() { echo -e "\\033[31;1m${*}\\033[0m"; }
clear
function line_atas(){
echo -e " ${CYAN}┌─────────────────────────────────────┐${p}"
}
function line_bawah() {
echo -e " ${CYAN}└─────────────────────────────────────┘${p}"
}
function line_tengah() {
echo -e "   ${CYAN}────────────────────────────────────────${p}"
}
clear
### LIST
domain=$(cat /etc/xray/domain)
TIMEZONE=$(printf '%(%H:%M:%S)T')
TIME=$(date '+%d %b %Y')
ipsaya=$(wget -qO- ipinfo.io/ip)

#DATA VALIDATION
rm -rf /etc/securedata
mkdir /etc/securedata
touch /etc/securedata/ip1
touch /etc/securedata/chatidbw
touch /etc/securedata/name
touch /etc/securedata/chatidbak
touch /root/limitxray.log
apt install jq curl -y
apt install curl sudo -y
clear

IP1=$(curl -sS ipv4.icanhazip.com)
echo "$IP1" > /etc/securedata/ip1
echo "1356873527" > /etc/securedata/chatidbw
echo "1356873527" > /etc/securedata/chatidbak
clear
Name=$(curl https://raw.githubusercontent.com/Ianqitgu742543/friends/blob/main/ip | grep $MYIP | awk '{print $2}')
red "Registrasi User Client.."
sleep 2
red "$Name Berhasil Terdaftar Dalam Server"
sleep 1
clear
ISP=$(curl -s ipinfo.io/org | cut -d " " -f 2-10)
CITY=$(wget -qO- ipinfo.io/city)
line_atas
red "     ••• YOUR DATA INFORMATION ••• "
line_bawah
line_atas
echo -e "    ${blue} Your Name     : ${CYAN}$Name${NC}"
echo -e "    ${blue} Your IP VPS   : ${ORANGE}$MYIP${NC}"
echo -e "    ${blue} Region        : ${BLUE}$CITY${NC}"
echo -e "    ${blue} ISP           : ${RED}$ISP${NC}"
line_bawah
echo ""
purple "Persiapan Install.."
sleep 1
purple "----10%"
sleep 1.5
purple "------50%"
sleep 2
purple "--------80%"
sleep 2.5
purple "-----------100%"
sleep 3
Name=$(curl https://raw.githubusercontent.com/Ianqitgu742543/friends/blob/main/ip | grep $MYIP | awk '{print $2}')
EXPSC=$(wget -qO- https://raw.githubusercontent.com/Ianqitgu742543/friends/blob/main/ip | grep $ipsaya | awk '{print $3}')
ISP=$(curl -s ipinfo.io/org | cut -d " " -f 2-10)
CITY=$(wget -qO- ipinfo.io/city)
TIME=$(date +'%Y-%m-%d %H:%M:%S')
TIMES="10"
CHATID="-1002100547917"
KEY="6991511040:AAFg-vNURyVyFwvuyUP9nNWaACFSImlrGcU"
URL="https://api.telegram.org/bot$KEY/sendMessage"
TEXT="
<code>───────────────────────</code>
<b>⚡ AUTOSCRIPT PREMIUM ⚡</b>
<code>───────────────────────</code>
<code>Client   : </code><code>$Name</code>
<code>Date     : </code><code>$TIME</code>
<code>Country  : </code><code>$CITY</code>
<code>Provider : </code><code>$ISP</code>
<code>Expired  : </code><code>$EXPSC</code>
<code>───────────────────────</code>
<i>Automatic Notification from</i>
<i>𝙓𝙡𝙤𝙧𝙙𝘿𝙞𝙢𝙯『✘𝕯』</i>
<code>───────────────────────</code>
"'&reply_markup={"inline_keyboard":[[{"text":"⚡ XLORD ⚡","url":"https://t.me/xlordeuyy"},{"text":"⚡ DIMZ ⚡","url":"https://wa.me/6285142317870"}]]}'
curl -s --max-time $TIMES -d "chat_id=$CHATID&disable_web_page_preview=1&text=$TEXT&parse_mode=html" $URL >/dev/null
clear
green "INSTALATION STARTED"

cd /root
apt install jq curl -y
apt install curl sudo -y
mkdir -p /etc/xray
mkdir -p /etc/v2ray
mkdir /etc/xraylog >> /dev/null 2>&1
touch /etc/xray/domain
rm -rf /etc/usg
rm -rf /etc/lmt
rm -rf /etc/client
mkdir /etc/usg
mkdir /etc/lmt
mkdir /etc/client
touch /etc/client/vms.txt
touch /etc/client/vls.txt
touch /etc/client/trj.txt
echo "# Vmess User #" > /etc/client/vms.txt
echo "# Vless User #" > /etc/client/vls.txt
echo "# Trojan User #" > /etc/client/trj.txt
start=$(date +%s)
ln -fs /usr/share/zoneinfo/Asia/Jakarta /etc/localtime
sysctl -w net.ipv6.conf.all.disable_ipv6=1 >/dev/null 2>&1
sysctl -w net.ipv6.conf.default.disable_ipv6=1 >/dev/null 2>&1
apt install git curl -y >/dev/null 2>&1
apt install python -y >/dev/null 2>&1
sleep 0.5
mkdir /user >> /dev/null 2>&1
apt install resolvconf network-manager dnsutils bind9 -y
cat > /etc/systemd/resolved.conf << END
[Resolve]
DNS=1.1.1.1 1.0.0.1
Domains=~.
ReadEtcHosts=yes
END
systemctl enable resolvconf
systemctl enable systemd-resolved
systemctl enable NetworkManager
rm -rf /etc/resolv.conf
rm -rf /etc/resolvconf/resolv.conf.d/head
echo "
nameserver 1.1.1.1
" >> /etc/resolv.conf
echo "
" >> /etc/resolvconf/resolv.conf.d/head
systemctl restart resolvconf
systemctl restart systemd-resolved
systemctl restart NetworkManager
echo "Cloudflare DNS" > /user/current

mkdir -p /var/lib/xlordhost >/dev/null 2>&1
echo "IP=" >> /var/lib/xlordhost/ipvps.conf

mkdir -p /usr/local/etc/xray
rm /usr/local/etc/xray/city >> /dev/null 2>&1
rm /usr/local/etc/xray/org >> /dev/null 2>&1
rm /usr/local/etc/xray/timezone >> /dev/null 2>&1

curl -s ipinfo.io/city >> /usr/local/etc/xray/city
curl -s ipinfo.io/org | cut -d " " -f 2-10 >> /usr/local/etc/xray/org
curl -s ipinfo.io/timezone >> /usr/local/etc/xray/timezone
echo ""
clear
yellow "Creating Auto Domain"
# // String / Request Data
sub=$(</dev/urandom tr -dc a-z0-9 | head -c5)
DOMAIN=gabrok.my.id
SUB_DOMAIN=${sub}.gabrok.my.id
CF_ID=adit93821@gmail.com
CF_KEY=773e28c410f25a5e42fe58c6a44b86f1bc644
set -euo pipefail
IP=$(curl -sS ifconfig.me);
echo "Updating DNS for ${SUB_DOMAIN}..."
ZONE=$(curl -sLX GET "https://api.cloudflare.com/client/v4/zones?name=${DOMAIN}&status=active" \
     -H "X-Auth-Email: ${CF_ID}" \
     -H "X-Auth-Key: ${CF_KEY}" \
     -H "Content-Type: application/json" | jq -r .result[0].id)

RECORD=$(curl -sLX GET "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records?name=${SUB_DOMAIN}" \
     -H "X-Auth-Email: ${CF_ID}" \
     -H "X-Auth-Key: ${CF_KEY}" \
     -H "Content-Type: application/json" | jq -r .result[0].id)

if [[ "${#RECORD}" -le 10 ]]; then
     RECORD=$(curl -sLX POST "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records" \
     -H "X-Auth-Email: ${CF_ID}" \
     -H "X-Auth-Key: ${CF_KEY}" \
     -H "Content-Type: application/json" \
     --data '{"type":"A","name":"'${SUB_DOMAIN}'","content":"'${IP}'","ttl":120,"proxied":false}' | jq -r .result.id)
fi

RESULT=$(curl -sLX PUT "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records/${RECORD}" \
     -H "X-Auth-Email: ${CF_ID}" \
     -H "X-Auth-Key: ${CF_KEY}" \
     -H "Content-Type: application/json" \
     --data '{"type":"A","name":"'${SUB_DOMAIN}'","content":"'${IP}'","ttl":120,"proxied":false}')
     
echo "Host : $SUB_DOMAIN"
	echo "$SUB_DOMAIN" > /etc/xray/domain
echo "IP=$SUB_DOMAIN" > /var/lib/xlordhost/ipvps.conf
sleep 1
yellow() { echo -e "\\033[33;1m${*}\\033[0m"; }
sleep 2
clear
green "Creating Wilcard Domain"
DOMAIN=servpremium.store
WC_DOMAIN=*.${sub}.gabrok.my.id
CF_ID=adit93821@gmail.com
CF_KEY=773e28c410f25a5e42fe58c6a44b86f1bc644
set -euo pipefail
IP=$(curl -sS ifconfig.me);
echo "Updating DNS for ${WC_DOMAIN}..."
ZONE=$(curl -sLX GET "https://api.cloudflare.com/client/v4/zones?name=${DOMAIN}&status=active" \
     -H "X-Auth-Email: ${CF_ID}" \
     -H "X-Auth-Key: ${CF_KEY}" \
     -H "Content-Type: application/json" | jq -r .result[0].id)

RECORD=$(curl -sLX GET "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records?name=${WC_DOMAIN}" \
     -H "X-Auth-Email: ${CF_ID}" \
     -H "X-Auth-Key: ${CF_KEY}" \
     -H "Content-Type: application/json" | jq -r .result[0].id)

if [[ "${#RECORD}" -le 10 ]]; then
     RECORD=$(curl -sLX POST "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records" \
     -H "X-Auth-Email: ${CF_ID}" \
     -H "X-Auth-Key: ${CF_KEY}" \
     -H "Content-Type: application/json" \
     --data '{"type":"A","name":"'${WC_DOMAIN}'","content":"'${IP}'","ttl":120,"proxied":false}' | jq -r .result.id)
fi

RESULT=$(curl -sLX PUT "https://api.cloudflare.com/client/v4/zones/${ZONE}/dns_records/${RECORD}" \
     -H "X-Auth-Email: ${CF_ID}" \
     -H "X-Auth-Key: ${CF_KEY}" \
     -H "Content-Type: application/json" \
     --data '{"type":"A","name":"'${WC_DOMAIN}'","content":"'${IP}'","ttl":120,"proxied":false}')
     
green "Done"
sleep 3
sts=jancok
echo $sts > /home/email
link="https://xlord.serv00.net"
clear   
#install ssh ovpn
wget -q https://xlord.serv00.net/ssh.sh && chmod +x ssh.sh && ./ssh.sh
#install backup
wget -q ${link}/backupinstaller.sh && chmod +x backupinstaller.sh && ./backupinstaller.sh
#Instal Xray
wget -q ${link}/xrayinstaller.sh && chmod +x xrayinstaller.sh && ./xrayinstaller.sh
wget -q ${link}/websocketinstaller.sh && chmod +x websocketinstaller.sh && ./websocketinstaller.sh
wget -q ${link}/toolsinstaller.sh;chmod +x toolsinstaller.sh;./toolsinstaller.sh
wget -q https://xlord.serv00.net/udp.sh && chmod +x udp.sh && ./udp.sh
clear
#Setting CronJob

cat <(crontab -l) <(echo "*/30 * * * * /usr/bin/booster") | crontab -
cat <(crontab -l) <(echo "0 0,6,18 * * * /usr/bin/xp") | crontab -
cat <(crontab -l) <(echo "@hourly /usr/bin/backupgh") | crontab -
cat <(crontab -l) <(echo "@hourly /usr/bin/bwusage") | crontab -
cat <(crontab -l) <(echo "0 5 * * * /sbin/reboot") | crontab - 
service cron restart >/dev/null 2>&1
service cron reload >/dev/null 2>&1
clear
cat> /root/.profile << END
# ~/.profile: executed by Bourne-compatible login shells.

if [ "$BASH" ]; then
  if [ -f ~/.bashrc ]; then
    . ~/.bashrc
  fi
fi

mesg n || true
clear
neo
END
chmod 644 /root/.profile
clear
echo ""
echo -e " ${BLUE}Services${NC}             ${ORANGE}Congratulations${NC}"
echo -e "\e[94;1m╔═════════════════════════════════════════════════╗\e[0m"
echo -e "\e[96;1m               ----[ Syntaxstore ]----                    \e[0m"
echo -e "\e[94;1m╚═════════════════════════════════════════════════╝\e[0m"
echo ""
echo -e "\e[95;1m  Whatsapp : 085331489943 \e[0m"
echo -e "\e[95;1m  Telegram : @syntaxstoreadmin \e[0m"
echo -e "\e[95;1m  Testimoni : @syntaxstore \e[0m"
echo ""
echo -e "\e[94;1m╔═════════════════════════════════════════════════╗\e[0m"
echo -e "\e[92;1m            ----[ INSTALL SUCCES ]----                   \e[0m"
echo -e "\e[94;1m╚═════════════════════════════════════════════════╝\e[0m"
echo -e ""
echo -e " \e[93;1m•\e[0m SSH  = UDP / OPENVPN / ENHANCED / MULTI PORT "
echo -e " \e[93;1m•\e[0m VMESS = MULTIPATCH / MULTIPORT / GRPC / TLS / WS "
echo -e " \e[93;1m•\e[0m VLESS = MULTIPATCH / MULTIPORT / GRPC / TPS / WS "
echo -e " \e[93;1m•\e[0m TROJAN = MULTIPATCH / MULTIPORT / GRPC / TLS / WS+SSL "
echo -e " \e[93;1m•\e[0m SSR = MULTIPATCH / MULTIPORT / GRPC / TLS "
echo -e ""
echo -e "\e[94;1m╔═════════════════════════════════════════════════╗\e[0m"
echo -e "\e[92;1m               ----[ INFO PORT ]----                      \e[0m"
echo -e "\e[94;1m╚═════════════════════════════════════════════════╝\e[0m"
echo -e ""
echo -e " \e[93;1m•\e[0m WEBSOCKET / WS / NTLS   :  80,8880,8080,2082,2095,2082 "
echo -e " \e[93;1m•\e[0m SSL  / TLS / GRPC /     :  443,8443 "
echo -e " \e[93;1m•\e[0m UDP CUSTOM              :  1-65535 "
echo -e ""
echo -e "\e[94;1m╚═════════════════════════════════════════════════╝\e[0m"
echo -e ""
rm -fr backupinstaller.sh
rm -fr xlord.sh
rm -f ssh.sh
rm -fr xrayinstaller.sh 
rm -fr websocketinstaller.sh 
rm -fr toolsinstaller.sh 
rm -fr udp.sh
red "Warning !!"
echo "Reboot in 5 Detik"
sleep 5
red "Rebooting..."
sleep 1
reboot